﻿import React, { useState, useRef, useEffect } from "react"
import { Check, ChevronDown, X, Search } from "lucide-react"
import { Badge } from "./badge"
import { cn } from "../../lib/utils"

export function Combobox({
  options = [],
  value = "",
  onChange,
  placeholder = "Select...",
  searchPlaceholder = "Search...",
  label,
  errorText,
  disabled = false,
  className
}) {
  const [isOpen, setIsOpen] = useState(false)
  const [search, setSearch] = useState("")
  const containerRef = useRef(null)

  useEffect(() => {
    function handleClickOutside(event) {
      if (containerRef.current && !containerRef.current.contains(event.target)) {
        setIsOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const filteredOptions = options.filter((option) =>
    option.label.toLowerCase().includes(search.toLowerCase())
  )

  const selectedOption = options.find((opt) => opt.value === value)

  return (
    <div ref={containerRef} className={cn("relative w-full flex flex-col gap-1.5 text-start", className)}>
      {label && (
        <span className="text-sm font-medium text-(--text-primary) select-none">
          {label}
        </span>
      )}
      <button
        type="button"
        disabled={disabled}
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          "flex h-10 w-full items-center justify-between rounded-sm border border-(--border-default) bg-paper px-3 py-2 text-sm text-(--text-primary) focus:outline-none focus:border-(--border-focus) focus:ring-1 focus:ring-(--border-focus) disabled:cursor-not-allowed disabled:bg-(--bg-disabled) disabled:text-(--text-muted) dark:bg-(--bg-card) dark:border-(--border-emphasis) cursor-pointer text-start",
          errorText && "border-(--status-error-fg)"
        )}
      >
        <span className={cn(!selectedOption && "text-(--text-muted)")}>
          {selectedOption ? selectedOption.label : placeholder}
        </span>
        <ChevronDown className="h-4 w-4 opacity-50 shrink-0" />
      </button>

      {isOpen && (
        <div className="absolute top-[calc(100%+4px)] inset-s-0 z-50 w-full rounded-md border border-(--border-default) bg-paper p-1 text-(--text-primary) shadow-(--shadow-2) dark:bg-(--bg-card-raised) dark:border-(--border-emphasis)">
          <div className="flex items-center border-b border-(--border-default) px-3 dark:border-(--border-emphasis) pb-1 pt-0.5">
            <Search className="h-4 w-4 opacity-50 me-2 shrink-0" />
            <input
              type="text"
              placeholder={searchPlaceholder}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="flex h-8 w-full bg-transparent py-1 text-sm outline-none placeholder:text-(--text-muted)"
            />
          </div>
          <div className="max-h-50 overflow-y-auto pt-1">
            {filteredOptions.length === 0 ? (
              <div className="py-6 text-center text-sm text-(--text-secondary)">
                No results found.
              </div>
            ) : (
              filteredOptions.map((opt) => {
                const isSelected = opt.value === value
                return (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => {
                      onChange(opt.value)
                      setIsOpen(false)
                      setSearch("")
                    }}
                    className={cn(
                      "w-full flex items-center justify-between px-2.5 py-2 text-sm rounded-xs hover:bg-(--bg-page-alt) dark:hover:bg-(--border-emphasis) text-start cursor-pointer",
                      isSelected && "text-(--ai-primary)"
                    )}
                  >
                    <span>{opt.label}</span>
                    {isSelected && <Check className="h-4 w-4" />}
                  </button>
                )
              })
            )}
          </div>
        </div>
      )}
      {errorText && <p className="text-xs text-(--status-error-fg)">{errorText}</p>}
    </div>
  )
}

/* Multi-Select Component */
export function MultiSelect({
  options = [],
  value = [],
  onChange,
  placeholder = "Select multiple...",
  label,
  className
}) {
  const [isOpen, setIsOpen] = useState(false)
  const containerRef = useRef(null)

  useEffect(() => {
    function handleClickOutside(event) {
      if (containerRef.current && !containerRef.current.contains(event.target)) {
        setIsOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const handleSelect = (val) => {
    if (value.includes(val)) {
      onChange(value.filter((v) => v !== val))
    } else {
      onChange([...value, val])
    }
  }

  return (
    <div ref={containerRef} className={cn("relative w-full flex flex-col gap-1.5 text-start", className)}>
      {label && (
        <span className="text-sm font-medium text-(--text-primary) select-none">
          {label}
        </span>
      )}
      <div
        onClick={() => setIsOpen(!isOpen)}
        className="flex min-h-10 w-full items-center justify-between rounded-sm border border-(--border-default) bg-paper px-3 py-1 text-sm text-(--text-primary) focus-within:border-(--border-focus) focus-within:ring-1 focus-within:ring-(--border-focus) dark:bg-(--bg-card) dark:border-(--border-emphasis) cursor-pointer"
      >
        <div className="flex flex-wrap gap-1 items-center">
          {value.length === 0 ? (
            <span className="text-(--text-muted)">{placeholder}</span>
          ) : (
            value.map((v) => {
              const opt = options.find((o) => o.value === v)
              return (
                <Badge
                  key={v}
                  variant="employee"
                  shape="pill"
                  className="flex items-center gap-1 py-0.5 px-2 font-medium"
                >
                  <span>{opt?.label || v}</span>
                  <X
                    className="h-3 w-3 cursor-pointer opacity-60 hover:opacity-100"
                    onClick={(e) => {
                      e.stopPropagation()
                      handleSelect(v)
                    }}
                  />
                </Badge>
              )
            })
          )}
        </div>
        <ChevronDown className="h-4 w-4 opacity-50 shrink-0" />
      </div>

      {isOpen && (
        <div className="absolute top-[calc(100%+4px)] inset-s-0 z-50 w-full rounded-md border border-(--border-default) bg-paper p-1 text-(--text-primary) shadow-(--shadow-2) dark:bg-(--bg-card-raised) dark:border-(--border-emphasis)">
          <div className="max-h-50 overflow-y-auto">
            {options.map((opt) => {
              const isSelected = value.includes(opt.value)
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => handleSelect(opt.value)}
                  className="w-full flex items-center justify-between px-2.5 py-2 text-sm rounded-xs hover:bg-(--bg-page-alt) dark:hover:bg-(--border-emphasis) text-start cursor-pointer"
                >
                  <span>{opt.label}</span>
                  {isSelected && <Check className="h-4 w-4 text-(--ai-primary)" />}
                </button>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
